An example that demonstrates how the OpenTracing extensions work with
asynchronous and streaming RPC calls.

## Usage
```
python store_server.py &
python store_client.py
```
