The repo has moved.
-------------------

https://github.com/opentracing-contrib/python-grpc
