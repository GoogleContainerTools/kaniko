A simple example showing how to set gRPC up to use OpenTracing.

## Usage
```
python trivial_server.py &
python trivial_client.py
```
