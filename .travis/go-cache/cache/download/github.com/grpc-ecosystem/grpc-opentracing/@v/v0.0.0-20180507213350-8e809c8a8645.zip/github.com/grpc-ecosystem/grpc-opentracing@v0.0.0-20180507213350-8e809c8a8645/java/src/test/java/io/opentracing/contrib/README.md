## Tests

To run tests for grpc-opentracing, run

```
$ gradle test
```

These tests use the protobuf-generated classes from grpc-example, which are located in `src/testgen`.
