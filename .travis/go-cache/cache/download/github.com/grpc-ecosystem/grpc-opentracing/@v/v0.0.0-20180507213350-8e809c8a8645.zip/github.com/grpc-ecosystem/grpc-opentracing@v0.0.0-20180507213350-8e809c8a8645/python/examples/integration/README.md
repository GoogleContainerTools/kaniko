An example showing how to connect gRPC's OpenTracing spans to other OpenTracing
spans.

## Usage
```
python integration_server.py &
python integration_client.py
```
