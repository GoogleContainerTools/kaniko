## crane copy

Efficiently copy a remote image from src to dst

### Synopsis

Efficiently copy a remote image from src to dst

```
crane copy [flags]
```

### Options

```
  -h, --help   help for copy
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

