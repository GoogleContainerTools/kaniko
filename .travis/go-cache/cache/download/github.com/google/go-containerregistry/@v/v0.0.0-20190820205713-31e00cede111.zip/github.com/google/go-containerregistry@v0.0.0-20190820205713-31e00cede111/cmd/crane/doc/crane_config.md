## crane config

Get the config of an image

### Synopsis

Get the config of an image

```
crane config [flags]
```

### Options

```
  -h, --help   help for config
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

