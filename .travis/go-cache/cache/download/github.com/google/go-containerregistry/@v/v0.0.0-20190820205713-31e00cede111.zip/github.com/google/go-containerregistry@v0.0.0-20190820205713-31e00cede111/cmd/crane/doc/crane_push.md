## crane push

Push image contents as a tarball to a remote registry

### Synopsis

Push image contents as a tarball to a remote registry

```
crane push [flags]
```

### Options

```
  -h, --help   help for push
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

