## crane delete

Delete an image reference from its registry

### Synopsis

Delete an image reference from its registry

```
crane delete [flags]
```

### Options

```
  -h, --help   help for delete
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

