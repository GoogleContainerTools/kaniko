## crane digest

Get the digest of an image

### Synopsis

Get the digest of an image

```
crane digest [flags]
```

### Options

```
  -h, --help   help for digest
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

