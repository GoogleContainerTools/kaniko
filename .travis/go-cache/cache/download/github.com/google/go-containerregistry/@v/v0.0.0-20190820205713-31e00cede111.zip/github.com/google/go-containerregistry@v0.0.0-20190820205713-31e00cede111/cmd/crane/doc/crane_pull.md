## crane pull

Pull a remote image by reference and store its contents in a tarball

### Synopsis

Pull a remote image by reference and store its contents in a tarball

```
crane pull [flags]
```

### Options

```
  -c, --cache_path string   Path to cache image layers
  -h, --help                help for pull
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

