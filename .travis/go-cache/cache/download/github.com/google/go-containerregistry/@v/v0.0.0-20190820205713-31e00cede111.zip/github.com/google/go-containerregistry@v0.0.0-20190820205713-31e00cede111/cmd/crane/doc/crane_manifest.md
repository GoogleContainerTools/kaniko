## crane manifest

Get the manifest of an image

### Synopsis

Get the manifest of an image

```
crane manifest [flags]
```

### Options

```
  -h, --help   help for manifest
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

