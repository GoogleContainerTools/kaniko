## crane version

Print the version

### Synopsis

Print the version

```
crane version [flags]
```

### Options

```
  -h, --help   help for version
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

