## crane validate

Validate that an image is well-formed

### Synopsis

Validate that an image is well-formed

```
crane validate [flags]
```

### Options

```
      --daemon string    Name of image in daemon to validate
  -h, --help             help for validate
      --remote string    Name of remote image to validate
      --tarball string   Path to tarball to validate
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

