## crane ls

List the tags in a repo

### Synopsis

List the tags in a repo

```
crane ls [flags]
```

### Options

```
  -h, --help   help for ls
```

### SEE ALSO

* [crane](crane.md)	 - Crane is a tool for managing container images

