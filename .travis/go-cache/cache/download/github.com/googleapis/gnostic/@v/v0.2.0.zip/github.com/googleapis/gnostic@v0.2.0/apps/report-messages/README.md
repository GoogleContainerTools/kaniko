# report-messages tool

This directory contains a command-line tool that provides a text
report listing the messages in a gnostic messages file.

