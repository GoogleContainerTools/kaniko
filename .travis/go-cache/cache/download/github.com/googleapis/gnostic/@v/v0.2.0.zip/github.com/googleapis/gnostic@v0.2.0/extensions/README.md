# Extensions

This directory contains support code for building Gnostic extensions and associated examples.

Extensions are used to compile vendor or specification extensions into protocol buffer structures.
