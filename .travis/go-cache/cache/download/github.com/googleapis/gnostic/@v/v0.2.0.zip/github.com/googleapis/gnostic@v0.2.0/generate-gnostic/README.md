# generate-gnostic

## The gnostic compiler generator

This directory contains code that generates a protocol buffer
representation and supporting code for a JSON schema.

It is currently used to build models of OpenAPI specifications
and extensions which are described as "vendor extensions" in 
OpenAPI 2.0 and "specification extensions" in OpenAPI 3.0.

For usage information, run the `generate-gnostic` binary with no
options.
