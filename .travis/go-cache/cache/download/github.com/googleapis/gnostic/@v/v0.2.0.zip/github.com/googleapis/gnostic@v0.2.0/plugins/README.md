# Plugins

This directory contains support code for building Gnostic plugins and associated examples.

Plugins are used to process API descriptions and can perform tasks like documentation and
code generation. Plugins can be written in any language that is supported by the Protocol
Buffer tools.
