# tools

This directory contains general utilities used by Gnostic and related programs.

## j2y2j 

Converts JSON to YAML and YAML to JSON.

## format-schema

Formats a JSON schema canonically.
