package azblob

const serviceLibVersion = "0.7"
