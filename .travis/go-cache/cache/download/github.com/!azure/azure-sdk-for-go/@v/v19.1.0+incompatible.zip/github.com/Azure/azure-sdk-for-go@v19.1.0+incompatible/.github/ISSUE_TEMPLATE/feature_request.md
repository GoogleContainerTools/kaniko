---
name: Feature Request
about: Request new features for the Go SDK.
---

### Feature Request

<!--
To help us better serve you, describe the feature you'd like and how it will help you.
-->


