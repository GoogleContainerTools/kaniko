### go-context - jbenet's CONText EXTensions

https://godoc.org/github.com/jbenet/go-context

- `WithDeadlineFraction`: https://godoc.org/github.com/jbenet/go-context/ext#WithDeadlineFraction
- `WithParents`: https://godoc.org/github.com/jbenet/go-context/ext#WithParents
- `io.{Reader, Writer}`: https://godoc.org/github.com/jbenet/go-context/io

