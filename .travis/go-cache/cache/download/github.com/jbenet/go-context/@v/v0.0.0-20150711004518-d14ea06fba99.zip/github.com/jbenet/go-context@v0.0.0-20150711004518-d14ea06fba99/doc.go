// Package context contains some extenstions to go.net/context by @jbenet
package context
