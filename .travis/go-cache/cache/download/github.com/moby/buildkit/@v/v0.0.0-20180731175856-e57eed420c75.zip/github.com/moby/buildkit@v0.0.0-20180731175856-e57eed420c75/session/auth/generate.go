package auth

//go:generate protoc --gogoslick_out=plugins=grpc:. auth.proto
