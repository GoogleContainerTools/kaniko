package client

const (
	ExporterImage  = "image"
	ExporterLocal  = "local"
	ExporterOCI    = "oci"
	ExporterDocker = "docker"
)
