package filesync

//go:generate protoc --gogoslick_out=plugins=grpc:. filesync.proto
