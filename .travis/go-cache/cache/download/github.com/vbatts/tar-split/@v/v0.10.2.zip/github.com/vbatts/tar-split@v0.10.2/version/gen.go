package version

// from `go get github.com/vbatts/go-get-version`
//go:generate go-get-version -package version -variable VERSION -output version.go
