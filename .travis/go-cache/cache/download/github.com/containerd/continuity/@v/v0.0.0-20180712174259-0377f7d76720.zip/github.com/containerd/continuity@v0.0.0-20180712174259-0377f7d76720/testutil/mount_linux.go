package testutil

import "golang.org/x/sys/unix"

const unmountFlags int = unix.MNT_DETACH
