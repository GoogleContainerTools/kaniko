// +build !windows

package fstest

var metadataFiles map[string]bool
