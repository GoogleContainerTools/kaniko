package proto

//go:generate protoc --go_out=. manifest.proto
