package sysx

import (
	"syscall"
)

const ENODATA = syscall.ENODATA
