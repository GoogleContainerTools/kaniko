package devices

import "fmt"

var ErrNotSupported = fmt.Errorf("not supported")
