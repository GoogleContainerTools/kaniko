// +build windows solaris

package commands

import (
	"github.com/spf13/cobra"
)

var MountCmd *cobra.Command = nil
