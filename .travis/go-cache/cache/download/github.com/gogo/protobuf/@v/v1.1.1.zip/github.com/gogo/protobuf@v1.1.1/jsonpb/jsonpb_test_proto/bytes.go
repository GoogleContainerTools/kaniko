package jsonpb

// Byte is used to test that []byte type aliases are serialized to base64.
type Byte byte

// Bytes is used to test that []byte type aliases are serialized to base64.
type Bytes []Byte
