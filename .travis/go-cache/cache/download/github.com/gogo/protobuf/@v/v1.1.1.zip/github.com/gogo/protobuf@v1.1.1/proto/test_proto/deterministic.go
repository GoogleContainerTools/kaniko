package test_proto

func (m *CustomDeterministicMarshaler) Marshal() ([]byte, error) {
	return []byte{}, nil
}
