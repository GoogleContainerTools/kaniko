<!--

    If you are unhappy how your favorite Go dependency management tool deals
    with this repository, please do not file an issue but read
    https://github.com/prometheus/client_golang#important-note-about-releases-versioning-tagging-stability-and-your-favorite-go-dependency-management-tool
    instead. Thank you very much.

-->
