package fsutil

//go:generate protoc --gogoslick_out=. stat.proto wire.proto
