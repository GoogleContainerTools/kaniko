This template is for testing snipmd.awk.

Put the first snippet here.

[snip]:# (first)

And now the second.
[snip]:# (second)

A top-level snippet.

[snip]:# (top-level)

```go
// A code block that is not included.
```

And we're done.
