// Package objfile implements encoding and decoding of object files.
package objfile
