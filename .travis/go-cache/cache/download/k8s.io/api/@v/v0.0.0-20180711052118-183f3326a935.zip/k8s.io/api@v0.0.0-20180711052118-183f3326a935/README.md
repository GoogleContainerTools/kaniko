This repo is still in the experimental stage. Shortly it will contain the schema of the API that are served by the Kubernetes apiserver.
